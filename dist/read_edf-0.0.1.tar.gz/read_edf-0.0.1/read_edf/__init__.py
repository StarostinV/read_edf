from .edf_reader import read_edf, CorruptedFileError
